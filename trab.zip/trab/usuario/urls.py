from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('recuperar-senha/', views.recuperar_senha_view, name='recuperar_senha'),
    path('alterar-senha/', views.alterar_senha_view, name='alterar_senha'),
    path('cadastrar/', views.cadastrar_view, name='cadastrar'),
    path('perfil/', views.perfil_view, name='perfil'),
    path('home/', views.home_view, name='home'),
]
