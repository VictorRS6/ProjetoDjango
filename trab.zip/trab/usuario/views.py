from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate

def login_view(request):
    # lógica do login
    return render(request, 'usuario/login.html')

def logout_view(request):
    # lógica do logout
    logout(request)
    return redirect('login')

def recuperar_senha_view(request):
    return render(request, 'usuario/recuperar_senha.html')

def alterar_senha_view(request):
    return render(request, 'usuario/alterar_senha.html')

def cadastrar_view(request):
    return render(request, 'usuario/cadastrar.html')

def perfil_view(request):
    return render(request, 'usuario/perfil.html')

def home_view(request):
    return render(request, 'usuario/home.html')
