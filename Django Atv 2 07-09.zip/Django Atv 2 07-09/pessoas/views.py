from django.shortcuts import render, redirect
from .models import Pessoa

def lista_pessoas(request):
    todas_as_pessoas = Pessoa.objects.all()
    
    return render(request, 'pessoas_list.html', {'pessoas': todas_as_pessoas})

def login_view(request):
    if request.method == 'POST':
        usuario = request.POST.get('username')
        senha = request.POST.get('password')
        
        print("--- DADOS DE LOGIN RECEBIDOS ---")
        print(f"Usuário: {usuario}")
        print(f"Senha: {senha}")
        print("--------------------------------")
        
        return redirect('lista_pessoas')
        
    return render(request, 'login.html')